---
name: onfire-prospecting
description: Run AI prospecting, score buyers and champions, resolve people and companies to verified LinkedIn profiles, enrich contacts with emails and phones, and edit prospecting schema config — all using the Onfire MCP. Use this skill whenever the user wants to prospect a company or list of companies, find decision makers or buyers at an account, score a specific person, look up a person or company from partial info (name, website, email), find LinkedIn URLs, get contact info (emails, phones), or iterate on prospecting schema configuration — even if they don't say the word "prospecting" (e.g. "who should I talk to at Acme", "find me champions at these accounts", "get emails for this list", "what's Lana Patel's LinkedIn", "resolve these CRM accounts", "tweak my hot keywords").
---

# Onfire Prospecting

This skill is the playbook for the Onfire MCP. It chains five tools so a user can go from any starting state — a name, a website, a messy CRM dump, a LinkedIn URL — to a ranked, scored, optionally enriched prospect list, or to an iteration on the prospecting engine itself.

This SKILL.md is the routing layer. When you commit to a tool, **read the matching reference file in `references/`** for input shapes, batch caps, output fields, polling rules, hard rules, pitfalls, and worked examples.

## The five tools

| Tool | Reference | Purpose |
|---|---|---|
| `match_company` | `references/match-company.md` | Resolve a company → verified LinkedIn URL + firmographics |
| `match_person` | `references/match-person.md` | Resolve a person → verified LinkedIn profile + current title/company |
| `ai_prospecting` | `references/ai-prospecting.md` | Rank prospects (`run`) or score one person (`get_prospect`) |
| `contact_data_enrichment` | `references/contact-data-enrichment.md` | Add verified emails/phones (paid; two-phase consent above 10) |
| `manage_ai_prospecting` | `references/manage-ai-prospecting.md` | Edit caller's schema via shadow lifecycle (draft → test → ship) |

**Dataset companion tools.** `ai_prospecting(action="run")` (and the `search_*` tools) return a `dataset_id` instead of the full row set. The full data lives in a short-lived MCP dataset that you analyse with these companions:

- `describe_dataset(dataset_id)` — schema + a head sample.
- `query_datasets({alias: dataset_id}, sql, row_limit=N)` — read-only DuckDB SQL on the parquet (filter, sort, slice, paginate).
- `list_datasets()` — see datasets produced earlier in this conversation (handy when comparing a live vs shadow run).

Use the relevant reference (`references/ai-prospecting.md`) for when and how to call them.

## Pick the path from intent, not from the input shape

Users say what they want; the input shape is just plumbing. Read intent first, then normalize inputs.

**"Prospect this account / list of accounts."**
*Examples: "Find buyers at Acme", "Who should I sell to at acme.com", "Run prospecting on these 30 companies."*

1. Need a company LinkedIn URL → `match_company` first (batch ≤100). See `references/match-company.md`.
2. `ai_prospecting` with `action="run"`. See `references/ai-prospecting.md` (covers polling + the dataset response shape).
3. The completed payload returns a **dataset handle + a small `preview_rows` sample**, not the full prospect list. Render the preview (`$$-onfire-bold-$$` conversion). Use `query_datasets` / `describe_dataset` against the returned `dataset_id` to slice or paginate the full list.
4. Make the enrichment offer (see below — required, not optional). Pass the run's `dataset_id` to `contact_data_enrichment` to enrich the entire run set without rebuilding contact dicts.

**"Score this specific person."**
*Examples: "Is Jane Doe at Acme worth talking to?"*

1. Get the company LinkedIn URL — `match_company` if missing.
2. Get the person LinkedIn URL — `match_person` (it usually returns the company URL too — reuse it).
3. `ai_prospecting` with `action="get_prospect"`. (Single record, returned inline — no dataset.)
4. Make the enrichment offer.

**"Who is this person / company?" (identity only, no scoring)**

Just `match_person` or `match_company`. Don't run prospecting unless asked.

**"Get me emails / phones."**

1. If the rows came from a recent `ai_prospecting` run, hand the run's `dataset_id` straight to `contact_data_enrichment` — no need to rebuild contact dicts.
2. Otherwise: if rows lack LinkedIn URLs, `match_person` first (batches ≤100), then enrich.
3. `contact_data_enrichment` — see `references/contact-data-enrichment.md` for the two-phase consent flow and the dataset-passthrough pattern.

**"Show me / change my prospecting config."**
*Examples: "What's in my schema?", "Tweak my hot keywords and test."*

`manage_ai_prospecting`. Always `get_my_schema` first. Test edits with `ai_prospecting(activate_shadow_run=True, ...)`. `ship_shadow(confirm=True)` is the destructive step. See `references/manage-ai-prospecting.md`.

## Input normalization

Get to a company LinkedIn URL before any prospecting call. The matchers do the heavy lifting — see `references/match-company.md` and `references/match-person.md` for input shapes. The pattern:

- Already have a clean LinkedIn URL → use it.
- Anything else (name, website, email, partial info) → matcher first, multi-signal entries when you have multiple fields.
- Lists → batch up to 100 per matcher call.
- Low-confidence match → surface it. Don't silently propagate ambiguity into a prospecting run.

## The enrichment offer (don't skip this)

After **every** prospecting run, tell the user they can pull verified emails and phones for any of the returned prospects — not just the rows in `preview_rows`. Users frequently assume contact data is gated to whatever's on screen; it isn't, and most of the value of the workflow is downstream of contact data.

Phrasing should feel natural, not boilerplate:

> "I can pull verified emails and phone numbers for any of these — top 5, all <total>, or a subset you pick. Just say which."

Use `total_prospects` / `filtered_prospects` from the run response so the "<total>" number is real. Make this offer regardless of how many prospects came back. To enrich the entire run, pass the run's `dataset_id` to `contact_data_enrichment(dataset_id=…, contacts=[], …)`; for a custom subset, build inline contact dicts.

## Hard rules (the things that bite)

- **Never pass `target_tenant_id`** on `ai_prospecting` or `contact_data_enrichment`. Tenant comes from OAuth.
- **Polling:** `ai_prospecting` may return `{"status": "still_running"}`. Call again with identical args. Not an error.
- **Batch caps:** `match_company` / `match_person` ≤100. `contact_data_enrichment` phase-2 ≤20.
- **Confirmation tokens are server-issued.** Don't fabricate, don't reuse across unrelated requests.
- **Two-phase consent above 10 contacts.** Show `user_facing_message` verbatim. Wait for explicit yes.
- **Don't promise prospect fields not in the seven returned.** See `references/ai-prospecting.md`.
- **Convert `$$-onfire-bold-$$` sentinels** to markdown bold before display.
- **Don't re-run `ai_prospecting` to "see more" prospects.** The run already produced the full set — use `query_datasets` / `describe_dataset` against the returned `dataset_id` instead.
- **Treat `preview_rows` as a sample, not the result.** The full list lives in the dataset; surface the total from `total_prospects` / `filtered_prospects`.
- **Surface low-confidence matches** from the matchers. Don't silently pick the top result.
- **`manage_ai_prospecting` is the shadow editor**, not a SQL surface. See `references/manage-ai-prospecting.md`.

## Worked examples

**Single company, name only.** *"Run prospecting on Datadog."*
1. `match_company` on "Datadog" → LinkedIn URL.
2. `ai_prospecting(action="run", company_linkedin_url=...)`. Poll if needed.
3. Render `preview_rows`, mention the total from `filtered_prospects`, make the enrichment offer (mention all <total> are available, not just the preview).

**A sheet of 40 accounts.** *User uploads a CSV with `company_name` and `website`.*
1. One `match_company` call with all 40 rows (multi-signal entries: both name and website).
2. Filter matched rows; flag unmatched.
3. `ai_prospecting(action="run", linkedin_urls=[...])`. Poll if needed.
4. Render preview. If user wants per-company groupings or xlsx of the full set, `query_datasets({"p": dataset_id}, "SELECT … ORDER BY COMPANY_LINKEDIN_URL")`. Make the enrichment offer (dataset_id passthrough).

**Person identity + score.** *"Score 'Lana Patel, VP Eng at Snowflake'."*
1. `match_person(entities=[{"person_full_name": "Lana Patel", "company_name": "Snowflake", "job_title": "VP Eng"}])`.
2. Reuse returned `company_linkedin_url`; otherwise `match_company` for Snowflake.
3. `ai_prospecting(action="get_prospect", company_linkedin_url=..., person_linkedin=...)`.
4. Score + reasoning. Make the enrichment offer.

**Enriching 150 contacts.**
1. If rows lack LinkedIn URLs, `match_person` first (batches ≤100).
2. `contact_data_enrichment` phase 1 (consent). Show `user_facing_message` verbatim. Stop.
3. On explicit yes: phase 2, 8 batches of ≤20 with the `confirmation_token`. Accumulate. Flag unresolvable rows.

**Enriching the full result of an ai_prospecting run.** *"Yes, get emails for everyone you found."*
1. Hand the run's `dataset_id` to `contact_data_enrichment` — `contacts=[]`, `dataset_id="ds_…"`, column-name params for the dataset's columns (`LINKEDIN_URL`, `COMPANY_LINKEDIN_URL`, `FULL_NAME`), `total_count` = `filtered_prospects` from the run.
2. Phase 1 consent. Show `user_facing_message`. Stop.
3. On explicit yes: phase 2 paginates the dataset itself via `limit` / `offset` — same `dataset_id`, same `confirmation_token`, ≤20 rows per call.

**Iterating on schema config.** *"Try my prospecting with these new hot keywords on Acme."*
1. `manage_ai_prospecting` `get_my_schema` → show current keywords.
2. `create_shadow` if none.
3. `update_shadow(patch={"hot_keywords": [...]})`.
4. `ai_prospecting(action="run", activate_shadow_run=True, company_linkedin_url=...)`.
5. Compare with the user (use `query_datasets` to diff the live and shadow datasets if useful). `ship_shadow(confirm=True)` or `discard_shadow`.
